JC MARINE - A4 Illustrator package

Files:
- JC_MARINE_A4_Front.ai: front, A4 210 x 297 mm.
- JC_MARINE_A4_Back.ai: back, A4 210 x 297 mm.
- JC_MARINE_A4.pdf: original two-page reference for comparison/import.

The .ai files use the legacy Illustrator 5 PostScript format, exported by a
compatible converter, not by the Adobe Illustrator application. The format
supports one page per file, so front and back are separate. All images are
embedded. No external image links are required.

Front: service text remains live Helvetica/Helvetica Bold text; card shapes
are vector objects. Header/footer artwork and product images are raster.
Back: branding artwork is embedded as separate image objects by logo region.
Raster artwork is not converted to editable vector paths or live text.

Open the .ai files with File > Open in Adobe Illustrator, then Save As to
create a current-version native Illustrator document. Adobe Illustrator is
not installed in the export environment, so opening in Illustrator itself
has not been tested. PostScript rendering and A4 dimensions were checked.

If your Illustrator version does not import legacy AI5, open the included
two-page PDF in Illustrator and Save As .ai. The PDF retains its original
vector and text objects, including the full original reverse-page artwork.
