#target illustrator
/* Open this script from Illustrator > File > Scripts > Other Script.
   Reads the accompanying two-page PDF and writes two genuine Illustrator files.
   Existing output files are never overwritten. No network requests are made. */
(function () {
    var root = new File($.fileName).parent;
    var source = new File(root.fsName + '/JC_MARINE_A4_HighRes.pdf');
    if (!source.exists) {
        source = File.openDialog('Select JC_MARINE_A4_HighRes.pdf');
        if (!source) { return; }
    }
    var destination = new Folder(source.parent.fsName + '/Native_AI');
    if (!destination.exists && !destination.create()) {
        alert('Cannot create Native_AI folder. Move the package to a writable folder and try again.');
        return;
    }
    function uniqueFile(stem) {
        var n = 1;
        var result = new File(destination.fsName + '/' + stem + '.ai');
        while (result.exists) {
            n++;
            result = new File(destination.fsName + '/' + stem + '_' + n + '.ai');
        }
        return result;
    }
    var oldPage = null;
    var current = null;
    var saved = [];
    try {
        oldPage = app.preferences.PDFFileOptions.pageToOpen;
        for (var index = 0; index < 2; index++) {
            app.preferences.PDFFileOptions.pageToOpen = index + 1;
            // Preserve application alerts, including any missing-font dialog.
            current = app.open(source);
            var r = current.artboards[0].artboardRect;
            var w = r[2] - r[0];
            var h = r[1] - r[3];
            if (Math.abs(w - 595.276) > 1 || Math.abs(h - 841.890) > 1) {
                throw new Error('Imported page is not A4. Import the full PDF page rather than artwork bounds.');
            }
            var options = new IllustratorSaveOptions();
            options.pdfCompatible = true;
            options.compressed = true;
            options.embedLinkedFiles = true;
            options.embedICCProfile = true;
            var name = index === 0 ? 'JC_MARINE_A4_Front_HighRes' : 'JC_MARINE_A4_Back_HighRes';
            var target = uniqueFile(name);
            current.saveAs(target, options);
            current.close(SaveOptions.DONOTSAVECHANGES);
            current = null;
            saved.push(target.fsName);
        }
        alert('Native Illustrator files saved:\n\n' + saved.join('\n\n'));
    } catch (error) {
        // Keep an unsaved imported document open so the user can inspect it.
        alert('Conversion stopped: ' + error.message + '\n\nYou can also open the PDF with File > Open, choose a page, and use File > Save As > Adobe Illustrator (.ai).');
    } finally {
        if (oldPage !== null) {
            try { app.preferences.PDFFileOptions.pageToOpen = oldPage; } catch (ignored) {}
        }
    }
}());
